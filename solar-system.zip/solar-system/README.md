# Build the Solar System with Three.js

Lets sculpt the Sun, planets, and stars, not merely as they exist in the cold void of space, but as they bloom in the wild garden of our imagination.

Watch the tutorial on [YouTube](https://youtu.be/5Wj3TnktlGc)

Also, fork and create something cool!